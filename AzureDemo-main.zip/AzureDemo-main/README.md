# AzureDemo

A simple tutorial website describing how to host an Apache webserver in a Docker container.

Tools used: Bootstrap, Apache, Docker, ACI (Azure Container Instances)

Docker Hub: [tmazyrko/azure-demo](https://hub.docker.com/r/tmazyrko/azure-demo) <br>
Live site: [acidemo.eastus2.azurecontainer.io](http://acidemo.eastus2.azurecontainer.io)